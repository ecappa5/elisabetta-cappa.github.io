# Hugo Blox Builder: Community Blox

Upload custom or community Hugo Blox to this folder and they will be automatically installed to your site, [ready for use in your pages](https://docs.hugoblox.com/getting-started/page-builder/).

Creating your own blox? [Follow the step-by-step tutorial](https://docs.hugoblox.com/getting-started/page-builder/).
